let a=parseInt(prompt("Ingrese a: ","")),b=parseInt(prompt("Ingrese b: ",""));

let resta=a-b;
console.log(resta);
let suma=a+b;
console.log(suma);
let multiplicacion=resta*suma;
document.write("El resultado final es: ",multiplicacion);