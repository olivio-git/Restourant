let numero=20,multiplo=3;

for(let i=0; i<=numero;i++){
    if(i%multiplo==0){
        document.write(": ",i)
    }
}   