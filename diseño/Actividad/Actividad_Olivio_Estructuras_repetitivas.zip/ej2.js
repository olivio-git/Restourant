let a=prompt("Ingrese A",""),b=prompt("Ingrese B",""),c=prompt("Ingrese C",""),d=100;

let aa=parseInt(a);
let bb=parseInt(b);
let cc=parseInt(c);

let suma=(aa+bb);
console.log(suma);
let resta=suma-cc;
console.log(resta);
let final=resta+d;

document.write("El resultado Final es: ",final);